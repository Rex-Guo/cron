# cronboot
Cron表达式生成器 基于bootstrap的界面

打开web/cronb/cron.htm即可。
web/cronb/cron/init.js为初始化的js
web/cronb/cron/cronboot.js为页面操作js
